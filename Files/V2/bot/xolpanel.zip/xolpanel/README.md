# xolpanel
```
apt update && apt install wget -y && wget https://raw.githubusercontent.com/sshXvpn/xolpanel/main/xolpanel.sh && chmod +x xolpanel.sh && ./xolpanel.sh
```